Please find attached the output to all test files from p3TestsCorrected in test-results/results.txt.

`How to run`

type `make list` to run the parser on the test file.
This will execute the typechecker on all test files one by one and pipe the output to results.txt,
The output will then displayed on the stdout.


