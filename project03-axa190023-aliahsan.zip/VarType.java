public enum VarType {
    String,
    Char,
    Int,
    Bool,
    Float,
    Void
}
