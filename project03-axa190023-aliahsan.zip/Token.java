interface Token
{
    public String toString(int t);

}